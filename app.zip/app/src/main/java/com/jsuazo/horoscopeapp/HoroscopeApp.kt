package com.jsuazo.horoscopeapp

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class HoroscopeApp: Application()