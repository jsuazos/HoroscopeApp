package com.jsuazo.horoscopeapp.domain.model

data class PredictionModel(
    val horoscope: String,
    val sign: String
)