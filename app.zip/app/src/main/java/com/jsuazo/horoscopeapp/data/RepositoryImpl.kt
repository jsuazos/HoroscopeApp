package com.jsuazo.horoscopeapp.data

import android.util.Log
import com.jsuazo.horoscopeapp.data.network.HoroscopeApiService
import com.jsuazo.horoscopeapp.data.network.response.PredictionResponse
import com.jsuazo.horoscopeapp.domain.model.PredictionModel
import com.jsuazo.horoscopeapp.domain.model.Repository
import retrofit2.Retrofit
import javax.inject.Inject

class RepositoryImpl @Inject constructor(private val apiService: HoroscopeApiService) : Repository {

    override suspend fun getPrediction(sign: String):PredictionModel? {
        runCatching { apiService.getHoroscope((sign)) }
            .onSuccess { return it.toDomain() }
            .onFailure { Log.i("error", "Ha ocurrido un error: ${it.message}") }
        return null
    }

}