package com.jsuazo.horoscopeapp.domain.model

enum class HoroscopeModel {
    Aries, Taurus, Gemini, Cancer, Leo, Virgo, Libra, Sagittarius, Scorpio, Aquarius, Pisces, Capricorn
}