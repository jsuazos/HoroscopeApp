package com.jsuazo.horoscopeapp.ui.luck

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class LuckViewModel @Inject constructor():ViewModel() {

}